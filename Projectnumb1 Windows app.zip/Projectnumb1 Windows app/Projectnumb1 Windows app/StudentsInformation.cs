﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projectnumb1_Windows_app
{
    internal class StudentsInformation
    {
        string name;
        string lastname;
        string nationalcode;
        string securitycode;

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NationalCode { get; set; }
        public string SecurityCode { get; set; }
    }
}
