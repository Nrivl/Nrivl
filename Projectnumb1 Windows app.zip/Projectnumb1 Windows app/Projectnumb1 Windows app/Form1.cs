namespace Projectnumb1_Windows_app
{
    public partial class Form1 : Form
    {
        StudentsInformation student = new StudentsInformation();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string LastName1 = LastNameBox.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            List<StudentsInformation> StudentsData = new List<StudentsInformation>();
            student.FirstName = FirstNameBox.Text;
            student.LastName = LastNameBox.Text;
            student.NationalCode = NationalCodebox.Text;
            student.SecurityCode = SecurityCodebox.Text;

            StudentsData.Add(student);

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = StudentsData;

            MessageBox.Show(student.FirstName);

        }

        private void FirstNameBox_TextChanged(object sender, EventArgs e)
        {
            string Name1 = FirstNameBox.Text;
        }

        private void NationalCode_TextChanged(object sender, EventArgs e)
        {
            string NationalCode1 = NationalCodebox.Text;
        }

        private void SecurityCodebox_TextChanged(object sender, EventArgs e)
        {
            string SecurityCode1 = SecurityCodebox.Text;
        }
    }
}
