﻿namespace Projectnumb1_Windows_app
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            FirstNameBox = new TextBox();
            LastNameBox = new TextBox();
            NationalCodebox = new TextBox();
            SecurityCodebox = new TextBox();
            dataGridView1 = new DataGridView();
            FirstName = new DataGridViewTextBoxColumn();
            LastName = new DataGridViewTextBoxColumn();
            NationalCode = new DataGridViewTextBoxColumn();
            SecurityCode = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(302, 283);
            button1.Name = "button1";
            button1.Size = new Size(153, 29);
            button1.TabIndex = 0;
            button1.Text = "Save Infromation";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(193, 41);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 1;
            label1.Text = "FirstName";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(193, 91);
            label2.Name = "label2";
            label2.Size = new Size(75, 20);
            label2.TabIndex = 2;
            label2.Text = "LastName";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(188, 143);
            label3.Name = "label3";
            label3.Size = new Size(101, 20);
            label3.TabIndex = 3;
            label3.Text = "NationalCode";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(193, 199);
            label4.Name = "label4";
            label4.Size = new Size(96, 20);
            label4.TabIndex = 4;
            label4.Text = "SecurityCode";
            // 
            // FirstNameBox
            // 
            FirstNameBox.Location = new Point(458, 34);
            FirstNameBox.Name = "FirstNameBox";
            FirstNameBox.Size = new Size(125, 27);
            FirstNameBox.TabIndex = 5;
            FirstNameBox.TextChanged += FirstNameBox_TextChanged;
            // 
            // LastNameBox
            // 
            LastNameBox.Location = new Point(458, 84);
            LastNameBox.Name = "LastNameBox";
            LastNameBox.Size = new Size(125, 27);
            LastNameBox.TabIndex = 6;
            LastNameBox.TextChanged += textBox2_TextChanged;
            // 
            // NationalCodebox
            // 
            NationalCodebox.Location = new Point(458, 136);
            NationalCodebox.Name = "NationalCodebox";
            NationalCodebox.Size = new Size(125, 27);
            NationalCodebox.TabIndex = 7;
            NationalCodebox.TextChanged += NationalCode_TextChanged;
            // 
            // SecurityCodebox
            // 
            SecurityCodebox.Location = new Point(458, 192);
            SecurityCodebox.Name = "SecurityCodebox";
            SecurityCodebox.Size = new Size(125, 27);
            SecurityCodebox.TabIndex = 8;
            SecurityCodebox.TextChanged += SecurityCodebox_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { FirstName, LastName, NationalCode, SecurityCode });
            dataGridView1.Location = new Point(117, 359);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(553, 188);
            dataGridView1.TabIndex = 9;
            // 
            // FirstName
            // 
            FirstName.DataPropertyName = "FirstName";
            FirstName.HeaderText = "FirstName";
            FirstName.MinimumWidth = 6;
            FirstName.Name = "FirstName";
            FirstName.Width = 125;
            // 
            // LastName
            // 
            LastName.DataPropertyName = "LastName";
            LastName.HeaderText = "LastName";
            LastName.MinimumWidth = 6;
            LastName.Name = "LastName";
            LastName.Width = 125;
            // 
            // NationalCode
            // 
            NationalCode.DataPropertyName = "NationalCode";
            NationalCode.HeaderText = "NationalCode";
            NationalCode.MinimumWidth = 6;
            NationalCode.Name = "NationalCode";
            NationalCode.Width = 125;
            // 
            // SecurityCode
            // 
            SecurityCode.DataPropertyName = "SecurityCode";
            SecurityCode.HeaderText = "SecurityCode";
            SecurityCode.MinimumWidth = 6;
            SecurityCode.Name = "SecurityCode";
            SecurityCode.Width = 125;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(852, 559);
            Controls.Add(dataGridView1);
            Controls.Add(SecurityCodebox);
            Controls.Add(NationalCodebox);
            Controls.Add(LastNameBox);
            Controls.Add(FirstNameBox);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox FirstNameBox;
        private TextBox LastNameBox;
        private TextBox NationalCodebox;
        private TextBox SecurityCodebox;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn FirstName;
        private DataGridViewTextBoxColumn LastName;
        private DataGridViewTextBoxColumn NationalCode;
        private DataGridViewTextBoxColumn SecurityCode;
    }
}
